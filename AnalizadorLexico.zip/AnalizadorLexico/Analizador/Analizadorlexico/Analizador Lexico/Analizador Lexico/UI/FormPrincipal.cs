﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AnalizadorLexico.Engine;

namespace AnalizadorLexico.UI
{
    public partial class FormPrincipal : Form
    {
        private Engine.AnalizadorLexico motorLexico;

        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
           
        }
    }
}
