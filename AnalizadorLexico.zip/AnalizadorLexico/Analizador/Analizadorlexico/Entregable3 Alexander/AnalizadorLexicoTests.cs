﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entregable3.Tests;
using System.IO;
using System.Linq;

namespace Entregable3.Tests
{
    [TestClass]
    public class AnalizadorLexicoTests
    {
        private string LeerArchivoPrueba(string nombreArchivo)
        {
            string path = Path.Combine("ArchivosDePrueba", nombreArchivo);
            return File.ReadAllText(path);
        }

        [TestMethod]
        public void Prueba1_Calculadora_DebeReconocerTokensYNoTenerErrores()
        {
            string codigo = LeerArchivoPrueba("Prueba1_Calculadora.cs.txt");
            var analizador = new AnalizadorLexico(codigo);
            analizador.Escanear();

            Assert.AreEqual(0, analizador.ErroresDetectados.Count);
            Assert.IsTrue(analizador.TokensReconocidos.Any(t => t.Tipo == "TK_PALABRA_RESERVADA" && t.Lexema == "int"));
            Assert.IsTrue(analizador.TokensReconocidos.Any(t => t.Tipo == "TK_IDENTIFICADOR" && t.Lexema == "SumarRango"));
        }

        [TestMethod]
        public void Prueba2_PruebaBasica_DebeReconocerTokensYNoTenerErrores()
        {
            string codigo = LeerArchivoPrueba("Prueba2_PruebaBasica.cs.txt");
            var analizador = new AnalizadorLexico(codigo);
            analizador.Escanear();

            Assert.AreEqual(0, analizador.ErroresDetectados.Count);
            Assert.IsTrue(analizador.TokensReconocidos.Any(t => t.Tipo == "TK_NUM_DECIMAL" && t.Lexema == "15.50"));
            Assert.IsTrue(analizador.TokensReconocidos.Any(t => t.Tipo == "TK_CADENA" && t.Lexema == "\"Hola mundo\""));
        }

        [TestMethod]
        public void Prueba3_PruebaErrores_DebeDetectarErroresLexicos()
        {
            string codigo = LeerArchivoPrueba("Prueba3_PruebaErrores.cs.txt");
            var analizador = new AnalizadorLexico(codigo);
            analizador.Escanear();

            Assert.IsTrue(analizador.ErroresDetectados.Count > 0);
            Assert.IsTrue(analizador.ErroresDetectados.Any(e => e.Descripcion.Contains("ERR_CADENA")));
            Assert.IsTrue(analizador.ErroresDetectados.Any(e => e.Descripcion.Contains("ERR_CAR")));
            Assert.IsTrue(analizador.ErroresDetectados.Any(e => e.Descripcion.Contains("ERR_NUM")));
            Assert.IsTrue(analizador.ErroresDetectados.Any(e => e.Descripcion.Contains("ERR_COMENTARIO")));
        }

        [TestMethod]
        public void PruebaExtra1_CaracterInvalidoYDeteccionDeLinea()
        {
            string codigo = "int x = 5;\n@#$~";
            var analizador = new AnalizadorLexico(codigo);
            analizador.Escanear();

            Assert.AreEqual(4, analizador.ErroresDetectados.Count);
            Assert.IsTrue(analizador.ErroresDetectados.All(e => e.Linea == 2));
        }

        [TestMethod]
        public void PruebaExtra2_ComentarioBloqueSinCerrar()
        {
            string codigo = "int a = 5;\n/* Este comentario no cierra\nint b = 10;";
            var analizador = new AnalizadorLexico(codigo);
            analizador.Escanear();

            Assert.IsTrue(analizador.ErroresDetectados.Any(e => e.Descripcion.Contains("ERR_COMENTARIO")));
        }
    }
}